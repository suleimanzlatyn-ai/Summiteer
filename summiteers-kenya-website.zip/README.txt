SUMMITEERS KENYA WEBSITE — PREVIEW BUILD

Files:
- index.html: Home
- experiences.html: Service / experience listings
- booking.html: Booking enquiry form
- about.html: About the brand
- gallery.html: Trail journal / visual gallery
- contact.html: Contact options
- styles.css: Responsive styling and animations
- script.js: Mobile navigation and enquiry-form behavior

HOW TO PREVIEW
Open index.html in a browser, or upload all files to a GitHub repository and import it into Vercel as a static site.

IMPORTANT BEFORE GOING LIVE
1. Confirm the real business phone/WhatsApp number and add a direct WhatsApp send integration to the booking form.
2. Confirm official email, address, prices, upcoming dates, package inclusions, cancellation rules and payment methods.
3. Replace the illustrative stock photography with approved Summiteers-owned photos from Instagram.
4. The booking form currently formats the enquiry and gives the visitor a copy button plus the official Instagram link. It does not send a booking to the business or collect payments automatically.
5. Experience categories are based on the supplied Instagram screenshot and public-facing information; confirm the full, current service list with the owner.
6. Connect a real booking backend / calendar and payment provider only after the owner confirms their workflow.

Design direction: deep forest green, warm limestone, acid-lime accents, large editorial type, responsive cards, motion, image-led pages and direct booking enquiry flow.
