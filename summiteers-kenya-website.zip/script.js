document.addEventListener('DOMContentLoaded',()=>{
  const toggle=document.querySelector('.menu-toggle');
  const nav=document.querySelector('.nav');
  if(toggle&&nav) toggle.addEventListener('click',()=>{const open=nav.classList.toggle('open');toggle.setAttribute('aria-expanded',String(open));toggle.textContent=open?'✕':'☰';});
  document.querySelectorAll('[data-year]').forEach(el=>el.textContent=new Date().getFullYear());
  const date=document.querySelector('#date');
  if(date){const today=new Date();date.min=new Date(today.getTime()-today.getTimezoneOffset()*60000).toISOString().split('T')[0];}
  const params=new URLSearchParams(location.search);
  const exp=document.querySelector('#experience');
  if(exp&&params.has('experience')){const wanted=params.get('experience');[...exp.options].forEach(o=>{if(o.text.toLowerCase().includes(wanted.toLowerCase().split(' ')[0]))exp.value=o.value;});}
  const form=document.querySelector('#booking-form');
  if(form) form.addEventListener('submit',e=>{
    e.preventDefault();
    if(!form.reportValidity())return;
    const data=new FormData(form);
    const lines=[
      'SUMMITEERS KENYA — TRIP ENQUIRY',
      '',
      `Name: ${data.get('name')}`,
      `Phone / WhatsApp: ${data.get('phone')}`,
      `Email: ${data.get('email')||'Not provided'}`,
      `Experience: ${data.get('experience')}`,
      `Preferred date: ${data.get('date')}`,
      `Group size: ${data.get('people')}`,
      `Experience level: ${data.get('level')}`,
      `Notes: ${data.get('notes')||'None'}`,
      '',
      'Please confirm availability, total price, inclusions and payment details.'
    ];
    const message=lines.join('\n');
    const result=document.querySelector('#form-result');
    result.textContent='Your trip enquiry is ready. Copy the message below and send it to Summiteers through Instagram DM. This website does not yet transmit or confirm bookings automatically.\n\n'+message;
    result.classList.add('show');
    const copyButton=document.createElement('button');
    copyButton.type='button';copyButton.className='btn btn-dark';copyButton.style.marginTop='12px';copyButton.textContent='Copy enquiry message';
    copyButton.addEventListener('click',async()=>{try{await navigator.clipboard.writeText(message);copyButton.textContent='Copied — open Instagram to send ↗';}catch(err){copyButton.textContent='Select and copy the enquiry text above.';}});
    const old=result.querySelector('button');if(old)old.remove();result.appendChild(copyButton);
    const ig=document.createElement('a');ig.href='https://www.instagram.com/summiteers.ke/';ig.target='_blank';ig.rel='noopener';ig.className='btn btn-lime';ig.style.marginTop='12px';ig.style.marginLeft='8px';ig.textContent='Open Summiteers Instagram ↗';result.appendChild(ig);
    result.scrollIntoView({behavior:'smooth',block:'center'});
  });
});